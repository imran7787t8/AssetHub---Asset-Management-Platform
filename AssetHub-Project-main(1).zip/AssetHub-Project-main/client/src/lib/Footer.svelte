<footer class="fixed bottom-0 left-0 z-20 w-full p-4 bg-[#4F1787] border-t border-[#EB3678] shadow md:flex md:items-center md:justify-between md:p-6 ">
    <span class="text-sm text-[#EB3678] sm:text-cente">© 2024 <a href="https://tsoc.dev" class="hover:underline">Timechain Summer of Code™</a>. All Rights Reserved.
    </span>
    <ul class="flex flex-wrap items-center mt-3 text-sm font-medium text-[#EB3678] sm:mt-0">
        <li>
            <a href="https://tsoc.dev" class="hover:underline text-[#EB3678] me-4 md:me-6">About Group L</a>
        </li>
        <li>
            <a href="https://linktr.ee/timechainsummerofcode2024" class="hover:underline me-4 md:me-6">Register for Asset Marketplace</a>
        </li>
    </ul>
</footer>

