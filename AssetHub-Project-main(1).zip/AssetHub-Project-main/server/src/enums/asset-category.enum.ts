export enum AssetCategory {
  GADGET = 'GADGET',
  DEAL = 'DEAL',
  SOFTWARE = 'SOFTWARE',
}
