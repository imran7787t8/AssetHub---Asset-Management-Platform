-- AlterTable
ALTER TABLE "Order" ADD COLUMN     "bitcoinTransactionId" TEXT;
